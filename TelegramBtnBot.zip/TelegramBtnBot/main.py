from utils.imports import *

bot = Bot(token = TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start (message: types.Message):
    await bot.send_message(message.from_user.id, "Hello <3, forum -> https://anonymcheats.ru", reply_markup=nav.mainMenu)



if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)