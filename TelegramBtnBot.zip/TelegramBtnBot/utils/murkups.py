from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

btn1 = KeyboardButton('btn1')
btn2 = KeyboardButton('btn2')

mainMenu = ReplyKeyboardMarkup(resize_keyboard=True)
mainMenu.add(btn1, btn2)